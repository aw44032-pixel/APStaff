# AP Staff Attendance (Android)

School: **AP INFOMIST INSTITUTE**  Slogan: *Be The Best You Can Be*

A fully offline staff attendance app. The web app (`app/src/main/assets/index.html`) runs inside an Android WebView. All records are kept in the app's localStorage on the phone. Backups can be shared as a file (WhatsApp, Gmail, Drive) and restored on another phone.

## What is in this project

```
APStaffAttendance/
  settings.gradle, build.gradle, gradle.properties, gradlew, gradle/wrapper/
  app/
    build.gradle                (applicationId com.apinfomist.staffattendance, minSdk 24, targetSdk 34)
    proguard-rules.pro
    src/main/AndroidManifest.xml
    src/main/assets/index.html  <- the complete attendance web app (edit this to change the app)
    src/main/java/com/apinfomist/staffattendance/
        SplashActivity.java     <- splash screen (school name, app name, slogan)
        MainActivity.java       <- WebView, back button, backup share, file restore, clipboard
    src/main/res/
        layout/activity_main.xml, activity_splash.xml
        values/strings.xml, colors.xml, themes.xml   values-night/colors.xml
        mipmap-*/ic_launcher*.png, mipmap-anydpi-v26/*.xml, drawable/ic_launcher_foreground.png
        xml/file_paths.xml      <- FileProvider paths for sharing the backup file
```

## Build the APK (Android Studio)

1. Install **Android Studio** (Hedgehog or newer) from developer.android.com/studio. First launch downloads the Android SDK; let it finish.
2. Unzip this project. In Android Studio choose **File > Open** and select the `APStaffAttendance` folder.
3. Wait for **Gradle sync** to finish (first time needs internet: it downloads Gradle 8.6 and the Android Gradle Plugin). If it asks to install SDK 34 or build tools, click Install.
4. Menu **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. When it finishes, click **locate** in the notification. The file is at:
   `app/build/outputs/apk/debug/app-debug.apk`

That APK is ready to install on any Android 7.0+ phone. Nothing else is required.

### Command line (optional)
```
cd APStaffAttendance
./gradlew assembleDebug        # Windows: gradlew.bat assembleDebug
```

## Install on a phone

1. Send `app-debug.apk` to the phone (WhatsApp, USB, Drive, email).
2. Tap the file. If Android says "Install unknown apps", allow it for that app (Files / WhatsApp) and tap Install.
3. Open **AP Staff Attendance** from the app drawer.

Install the same APK on the vice principal's phone. Each phone keeps its own records; use **Settings > Download backup file** on one phone and **Restore from file** on the other to copy the data.

## Signed release APK (optional, for wider distribution)

Build > Generate Signed Bundle / APK > APK > Create new keystore (keep the keystore file and passwords safe; the same key is needed for every future update) > release. Output: `app/build/outputs/apk/release/app-release.apk`.

## Updating the app

Edit `app/src/main/assets/index.html`, increase `versionCode` in `app/build.gradle`, rebuild. Installing the new APK over the old one keeps all saved data.

## Notes

- No INTERNET permission is declared: the app cannot reach the network at all.
- External `http/https` links are blocked inside the WebView; `tel:` links open the phone dialer.
- The hardware back button closes an open form first, then returns to the Today tab, then exits.
- Data lives in the app's WebView storage. Uninstalling the app deletes it, so take backups.
