# Keep the JavaScript bridge methods so the WebView can call them
-keepclassmembers class com.apinfomist.staffattendance.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
