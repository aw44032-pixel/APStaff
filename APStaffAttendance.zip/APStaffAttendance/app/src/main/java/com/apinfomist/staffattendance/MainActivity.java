package com.apinfomist.staffattendance;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    private static final String START_URL = "file:///android_asset/index.html";

    private WebView webView;
    private ValueCallback<Uri[]> pendingFileChooser;

    // Handles the "Restore from file" picker inside the web app
    private final ActivityResultLauncher<Intent> fileChooserLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (pendingFileChooser == null) return;
                Uri[] uris = null;
                if (result.getResultCode() == RESULT_OK && result.getData() != null && result.getData().getData() != null) {
                    uris = new Uri[]{result.getData().getData()};
                }
                pendingFileChooser.onReceiveValue(uris);
                pendingFileChooser = null;
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        setupWebView();

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(START_URL);
        }

        // Android back button: let the page close its sheets / return to Today first,
        // then fall back to WebView history, then exit the app.
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                webView.evaluateJavascript(
                        "(function(){ try { return window.__androidBack ? !!window.__androidBack() : false; } catch(e) { return false; } })()",
                        value -> {
                            if ("true".equals(value)) return;          // page handled it
                            if (webView.canGoBack()) { webView.goBack(); return; }
                            setEnabled(false);
                            getOnBackPressedDispatcher().onBackPressed(); // exit
                        });
            }
        });
    }

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // required for localStorage
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(true);

        webView.setBackgroundColor(getResources().getColor(R.color.paper, getTheme()));
        webView.addJavascriptInterface(new AndroidBridge(), "Android");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(Uri.parse(url));
            }

            private boolean handleUrl(Uri uri) {
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                // Keep the app's own pages inside the WebView
                if ("file".equals(scheme) || "about".equals(scheme) || "javascript".equals(scheme) || "blob".equals(scheme) || "data".equals(scheme)) {
                    return false;
                }
                // Phone numbers (parent/teacher phone) open the dialer; anything else is blocked
                if ("tel".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_DIAL, uri));
                    } catch (Exception ignored) { }
                    return true;
                }
                // http/https etc.: the app is offline-only, so do not leave the app
                Toast.makeText(MainActivity.this, "External links are disabled in this app", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            // Makes <input type="file"> (Restore from file) work inside the WebView
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> filePathCallback, FileChooserParams params) {
                if (pendingFileChooser != null) {
                    pendingFileChooser.onReceiveValue(null);
                }
                pendingFileChooser = filePathCallback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "application/octet-stream"});
                try {
                    fileChooserLauncher.launch(intent);
                } catch (Exception e) {
                    pendingFileChooser = null;
                    Toast.makeText(MainActivity.this, "No file picker available", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    protected void onPause() {
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }

    /** Functions the web page can call as window.Android.* */
    public class AndroidBridge {

        /** Copy text (reports, backup text) to the clipboard. */
        @JavascriptInterface
        public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(ClipData.newPlainText("AP Staff Attendance", text));
                    Toast.makeText(MainActivity.this, R.string.copied, Toast.LENGTH_SHORT).show();
                }
            });
        }

        /** Save the backup JSON to a file and open the Android share sheet (WhatsApp, Gmail, Drive...). */
        @JavascriptInterface
        public void saveBackup(String fileName, String content) {
            runOnUiThread(() -> {
                try {
                    File dir = new File(getCacheDir(), "backups");
                    if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("cannot create dir");
                    String safeName = fileName == null || fileName.isEmpty() ? "staff-attendance-backup.json" : fileName.replaceAll("[^A-Za-z0-9._-]", "_");
                    File f = new File(dir, safeName);
                    try (OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(f), StandardCharsets.UTF_8)) {
                        w.write(content);
                    }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType("application/json");
                    share.putExtra(Intent.EXTRA_STREAM, uri);
                    share.putExtra(Intent.EXTRA_SUBJECT, safeName);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, getString(R.string.share_backup)));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not create backup file", Toast.LENGTH_SHORT).show();
                }
            });
        }

        /** Show a short native message. */
        @JavascriptInterface
        public void toast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }
    }
}
